import logging
import azure.functions as func
import pandas as pd
import os

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("🔍 Processing request to generate summary.")
    
    try:
        home_dir = os.environ["HOME"]
        csv_path = os.path.join(home_dir, "site", "wwwroot", "data", "mock_patients.csv")
        logging.info(f"📁 Trying to read file at: {csv_path}")
        
        df = pd.read_csv(csv_path)
        summary = df['risk_level'].value_counts().to_dict()
        return func.HttpResponse(str(summary), status_code=200)
    
    except Exception as e:
        logging.error(f"❌ Error generating summary: {e}")
        return func.HttpResponse("Failed to generate summary", status_code=500)
